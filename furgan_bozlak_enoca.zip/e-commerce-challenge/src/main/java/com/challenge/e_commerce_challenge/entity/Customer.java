package com.challenge.e_commerce_challenge.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "customers")
public class Customer extends BaseEntity{
    private String firstName;
    private String lastName;
    private String email;

    @Column(unique = true, nullable = false)
    private String phoneNumber;
}
