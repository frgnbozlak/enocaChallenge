package com.challenge.e_commerce_challenge.controller;

import com.challenge.e_commerce_challenge.dto.CartDto;
import com.challenge.e_commerce_challenge.dto.CartItemDto;
import com.challenge.e_commerce_challenge.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/carts")
public class CartController {
    private final CartService cartService;

    @GetMapping("/{customerId}")
    public ResponseEntity<CartDto> getCart(@PathVariable Long customerId) {
        CartDto cartDto = cartService.getCart(customerId);
        return ResponseEntity.ok(cartDto);
    }

    @PostMapping("/{customerId}/add")
    public ResponseEntity<Void> addProductToCart(@PathVariable Long customerId, @RequestBody CartItemDto cartItemDto) {
        cartService.addProductToCart(customerId, cartItemDto);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/{customerId}/remove/{productId}")
    public ResponseEntity<Void> removeProductFromCart(@PathVariable Long customerId, @PathVariable Long productId) {
        cartService.removeProductFromCart(customerId, productId);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{customerId}/changeQuantity/{productId}")
    public ResponseEntity<Void> changeProductQuantity(@PathVariable Long customerId, @PathVariable Long productId, @RequestParam int quantity) {
        cartService.changeProductQuantity(customerId, productId, quantity);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{customerId}/empty")
    public ResponseEntity<Void> emptyCart(@PathVariable Long customerId) {
        cartService.emptyCart(customerId);
        return ResponseEntity.noContent().build();
    }
}