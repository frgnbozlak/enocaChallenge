package com.challenge.e_commerce_challenge.mapper;

import com.challenge.e_commerce_challenge.dto.CartDto;
import com.challenge.e_commerce_challenge.entity.Cart;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface CartMapper {

    CartDto toDto(Cart cart);

    Cart toEntity(CartDto cartDto);
}
