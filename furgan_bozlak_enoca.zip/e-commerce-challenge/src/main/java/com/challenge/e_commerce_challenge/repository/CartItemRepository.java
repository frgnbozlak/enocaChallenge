package com.challenge.e_commerce_challenge.repository;

import com.challenge.e_commerce_challenge.entity.Cart;
import com.challenge.e_commerce_challenge.entity.CartItem;
import com.challenge.e_commerce_challenge.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    CartItem findByCartAndProduct(Cart cart, Product product);
    CartItem findByCartAndProductId(Cart cart, Long productId);

}
