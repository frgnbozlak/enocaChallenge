package com.challenge.e_commerce_challenge.mapper;

import com.challenge.e_commerce_challenge.dto.CartItemDto;
import com.challenge.e_commerce_challenge.entity.CartItem;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CartItemMapper {

    CartItemDto toDto(CartItem cartItem);

    CartItem toEntity(CartItemDto cartItemDto);
}
