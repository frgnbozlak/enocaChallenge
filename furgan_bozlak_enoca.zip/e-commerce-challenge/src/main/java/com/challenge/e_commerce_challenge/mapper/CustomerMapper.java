package com.challenge.e_commerce_challenge.mapper;

import com.challenge.e_commerce_challenge.dto.CustomerDto;
import com.challenge.e_commerce_challenge.entity.Customer;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CustomerMapper {
    CustomerMapper INSTANCE = Mappers.getMapper(CustomerMapper.class);

    CustomerDto toDto(Customer customer);
    Customer toEntity(CustomerDto customerDto);
}
