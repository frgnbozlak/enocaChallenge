package com.challenge.e_commerce_challenge.service;

import com.challenge.e_commerce_challenge.dto.CartDto;
import com.challenge.e_commerce_challenge.dto.CartItemDto;
import com.challenge.e_commerce_challenge.dto.OrderDto;
import com.challenge.e_commerce_challenge.dto.OrderItemDto;
import com.challenge.e_commerce_challenge.entity.*;
import com.challenge.e_commerce_challenge.repository.OrderItemRepository;
import com.challenge.e_commerce_challenge.repository.OrderRepository;
import com.challenge.e_commerce_challenge.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;


@Service
@RequiredArgsConstructor
public class OrderService {
    private final OrderRepository orderRepository;
    private final CartService cartService;
    private final ProductRepository productRepository;
    private final OrderItemRepository orderItemRepository;

    @Transactional
    public OrderDto placeOrder(Long customerId) {
        CartDto cartDto = cartService.getCart(customerId);

        if (cartDto.getItems().isEmpty()) {
            throw new RuntimeException("Sepet boş; sipariş verilemez.");
        }

        Order order = new Order();
        Customer customer = new Customer();
        customer.setId(customerId);
        order.setCustomer(customer);
        order.setTotalPrice(cartDto.getTotalPrice());
        order = orderRepository.save(order);

        for (CartItemDto item : cartDto.getItems()) {
            Product product = productRepository.findById(item.getProductId())
                    .orElseThrow(() -> new RuntimeException("Ürün bulunamadı."));

            if (product.getStockQuantity() < item.getQuantity()) {
                throw new RuntimeException("Yetersiz stok.");
            }

            product.setStockQuantity(product.getStockQuantity() - item.getQuantity());
            productRepository.save(product);

            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setProduct(product);
            orderItem.setPrice(product.getPrice());
            orderItem.setQuantity(item.getQuantity());
            orderItemRepository.save(orderItem);
        }

        cartService.emptyCart(customerId);

        return new OrderDto(order.getId(), order.getCustomer().getId(), order.getTotalPrice(), new ArrayList<>()); // Sipariş DTO'su döndür
    }

    public OrderDto getOrderForCode(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Sipariş bulunamadı."));

        List<OrderItemDto> orderItems = order.getOrderItems().stream()
                .map(orderItem -> new OrderItemDto(
                        orderItem.getId(),
                        order.getId(),
                        orderItem.getProduct().getId(),
                        orderItem.getQuantity(),
                        orderItem.getPrice()
                ))
                .toList();

        return new OrderDto(order.getId(), order.getCustomer().getId(), order.getTotalPrice(), orderItems); // Return Order DTO
    }

    public List<OrderDto> getAllOrdersForCustomer(Long customerId) {
        List<Order> orders = orderRepository.findByCustomerId(customerId);
        return orders.stream()
                .map(order -> new OrderDto(order.getId(), order.getCustomer().getId(), order.getTotalPrice(), new ArrayList<>())) // Pass an empty list
                .toList();
    }
}