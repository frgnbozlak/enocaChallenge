package com.challenge.e_commerce_challenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommerceChallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommerceChallengeApplication.class, args);
	}

}
