package com.challenge.e_commerce_challenge.mapper;

import com.challenge.e_commerce_challenge.dto.OrderDto;
import com.challenge.e_commerce_challenge.entity.Order;
import com.challenge.e_commerce_challenge.entity.OrderItem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface OrderMapper {

    OrderDto toDto(Order order);

    Order toEntity(OrderDto orderDto);

}
