package com.challenge.e_commerce_challenge.service;

import com.challenge.e_commerce_challenge.dto.CartDto;
import com.challenge.e_commerce_challenge.dto.CartItemDto;
import com.challenge.e_commerce_challenge.entity.*;

import com.challenge.e_commerce_challenge.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;


@Service
@RequiredArgsConstructor
public class CartService {
    private final CartRepository cartRepository;
    private final ProductRepository productRepository;
    private final CartItemRepository cartItemRepository;
    private final CustomerRepository customerRepository;


    public void addProductToCart(Long customerId, CartItemDto cartItemDto) {
        Cart cart = cartRepository.findByCustomerId(customerId);

        // Eğer sepet yoksa,  sepet oluşturur.
        if (cart == null) {
            cart = new Cart();
            Customer customer = customerRepository.findById(customerId)
                    .orElseThrow(() -> new RuntimeException("Müşteri bulunamadı."));
            cart.setCustomer(customer);
            cart = cartRepository.save(cart);
        }


        Product product = productRepository.findById(cartItemDto.getProductId())
                .orElseThrow(() -> new RuntimeException("Ürün bulunamadı."));


        if (product.getStockQuantity() < cartItemDto.getQuantity()) {
            throw new RuntimeException("Yetersiz stok.");
        }

        CartItem cartItem = cartItemRepository.findByCartAndProduct(cart, product);
        if (cartItem == null) {
            cartItem = new CartItem();
            cartItem.setCart(cart);
            cartItem.setProduct(product);
            cartItem.setQuantity(cartItemDto.getQuantity());
            cartItem.setPrice(product.getPrice());
            cart.getItems().add(cartItem);
        } else {

            cartItem.setQuantity(cartItem.getQuantity() + cartItemDto.getQuantity());
            cartItem.setPrice(product.getPrice());
        }

        cartItemRepository.save(cartItem);


        updateTotalPrice(cart);
    }

    public CartDto getCart(Long customerId) {
        Cart cart = cartRepository.findByCustomerId(customerId);
        if (cart == null) {
            throw new RuntimeException("Sepet bulunamadı.");
        }

        CartDto cartDto = new CartDto();
        cartDto.setId(cart.getId());
        cartDto.setCustomerId(customerId);
        cartDto.setTotalPrice(cart.getTotalPrice());

        List<CartItemDto> cartItemDtos = cart.getItems().stream()
                .map(cartItem -> {
                    CartItemDto dto = new CartItemDto();
                    dto.setCartId(cartItem.getCart().getId());
                    dto.setId(cartItem.getId());
                    dto.setProductId(cartItem.getProduct().getId());
                    dto.setQuantity(cartItem.getQuantity());
                    dto.setPrice(cartItem.getPrice());
                    return dto;
                })
                .collect(Collectors.toList());
        cartDto.setItems(cartItemDtos);

        return cartDto;
    }




    public void removeProductFromCart(Long customerId, Long productId) {
        Cart cart = cartRepository.findByCustomerId(customerId);
        if (cart == null) {
            throw new RuntimeException("Sepet bulunamadı.");
        }

        CartItem cartItem = cartItemRepository.findByCartAndProductId(cart, productId);
        if (cartItem == null) {
            throw new RuntimeException("Sepette bu ürün yok.");
        }

        cartItemRepository.delete(cartItem);
        updateTotalPrice(cart);
    }

    public void changeProductQuantity(Long customerId, Long productId, int quantity) {
        Cart cart = cartRepository.findByCustomerId(customerId);
        if (cart == null) {
            throw new RuntimeException("Sepet bulunamadı.");
        }

        CartItem cartItem = cartItemRepository.findByCartAndProductId(cart, productId);
        if (cartItem == null) {
            throw new RuntimeException("Sepette bu ürün yok.");
        }

        Product product = productRepository.findById(productId).orElseThrow(() -> new RuntimeException("Ürün bulunamadı."));
        if (product.getStockQuantity() < quantity) {
            throw new RuntimeException("Yetersiz stok.");
        }

        cartItem.setQuantity(quantity);
        cartItemRepository.save(cartItem);
        updateTotalPrice(cart);
    }

    private void updateTotalPrice(Cart cart) {
        BigDecimal totalPrice = cart.getItems().stream()
                .map(cartItem -> cartItem.getPrice().multiply(BigDecimal.valueOf(cartItem.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        cart.setTotalPrice(totalPrice);
        cartRepository.save(cart);
    }

    public void emptyCart(Long customerId) {
        Cart cart = cartRepository.findByCustomerId(customerId);
        if (cart == null) {
            throw new RuntimeException("Sepet bulunamadı.");
        }

        cartItemRepository.deleteAll(cart.getItems());
        cart.getItems().clear();
        cart.setTotalPrice(BigDecimal.ZERO);
        cartRepository.save(cart);
    }

}