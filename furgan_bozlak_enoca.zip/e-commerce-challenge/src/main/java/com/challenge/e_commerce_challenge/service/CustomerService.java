package com.challenge.e_commerce_challenge.service;

import com.challenge.e_commerce_challenge.dto.CustomerDto;
import com.challenge.e_commerce_challenge.entity.Customer;
import com.challenge.e_commerce_challenge.mapper.CustomerMapper;
import com.challenge.e_commerce_challenge.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class CustomerService {
    private final CustomerRepository customerRepository;

    public CustomerDto addCustomer(CustomerDto customerDto) {
        Customer customer = CustomerMapper.INSTANCE.toEntity(customerDto);
        Customer savedCustomer = customerRepository.save(customer);
        return CustomerMapper.INSTANCE.toDto(savedCustomer);
    }
}