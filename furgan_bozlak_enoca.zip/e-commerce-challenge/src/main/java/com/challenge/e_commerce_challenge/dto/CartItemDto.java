package com.challenge.e_commerce_challenge.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class CartItemDto {
    private Long id;
    private Long cartId;
    private Long productId;
    private int quantity;
    private BigDecimal price;
}
