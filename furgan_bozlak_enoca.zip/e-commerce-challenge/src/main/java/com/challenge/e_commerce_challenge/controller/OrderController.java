package com.challenge.e_commerce_challenge.controller;

import com.challenge.e_commerce_challenge.dto.OrderDto;
import com.challenge.e_commerce_challenge.entity.Order;
import com.challenge.e_commerce_challenge.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderService orderService;

    @PostMapping("/{customerId}")
    public ResponseEntity<OrderDto> placeOrder(@PathVariable Long customerId) {
        try {
            OrderDto orderDto = orderService.placeOrder(customerId);
            return new ResponseEntity<>(orderDto, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<OrderDto> getOrderForCode(@PathVariable Long orderId) {
        try {
            OrderDto orderDto = orderService.getOrderForCode(orderId);
            return new ResponseEntity<>(orderDto, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<OrderDto>> getAllOrdersForCustomer(@PathVariable Long customerId) {
        List<OrderDto> orders = orderService.getAllOrdersForCustomer(customerId);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }
}