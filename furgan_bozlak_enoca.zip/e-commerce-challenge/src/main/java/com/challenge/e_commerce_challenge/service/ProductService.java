package com.challenge.e_commerce_challenge.service;

import com.challenge.e_commerce_challenge.dto.ProductDto;
import com.challenge.e_commerce_challenge.entity.Product;
import com.challenge.e_commerce_challenge.mapper.ProductMapper;
import com.challenge.e_commerce_challenge.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;

    public List<ProductDto> getAllProducts() {
        return ProductMapper.INSTANCE.toDtoList(productRepository.findAll());
    }

    public ProductDto getProductById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        return ProductMapper.INSTANCE.toDto(product);
    }

    public ProductDto createProduct(ProductDto productDTO) {
        Product product = ProductMapper.INSTANCE.toEntity(productDTO);
        Product savedProduct = productRepository.save(product);
        return ProductMapper.INSTANCE.toDto(savedProduct);
    }

    public ProductDto updateProduct(Long id, ProductDto productDTO) {
        Product existingProduct = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        existingProduct.setId(productDTO.getId());
        existingProduct.setName(productDTO.getName());
        existingProduct.setDescription(productDTO.getDescription());
        existingProduct.setPrice(productDTO.getPrice());
        existingProduct.setStockQuantity(productDTO.getStockQuantity());

        Product updatedProduct = productRepository.save(existingProduct);
        return ProductMapper.INSTANCE.toDto(updatedProduct);
    }

    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }
}