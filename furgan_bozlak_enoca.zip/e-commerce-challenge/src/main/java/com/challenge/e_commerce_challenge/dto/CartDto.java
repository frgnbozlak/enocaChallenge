package com.challenge.e_commerce_challenge.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
public class CartDto {
    private Long id;
    private Long customerId;
    private BigDecimal totalPrice;
    private List<CartItemDto> items; // Sepetteki ürünler
}
