# E-Commerce Management System

Bu proje,  java challenge için istenen bir e-ticaret yönetim sistemidir . Spring Boot Java 17, Flyway, Hibernate, JPA, PostgreSQL ve Docker kullanılarak geliştirilmiştir. 


## Özellikler

- **Sipariş İşlemleri**: Kullanıcılar, ürünleri sepete ekleyebilir ve sipariş verebilir. Sipariş verildiğinde, ilgili sepet güncellenir.
- **Ürün Fiyatlarının İzlenmesi**: `OrderService` içinde, `OrderItem` oluşturulurken ürünün mevcut fiyatı alınarak `OrderItem`'a kaydedilir. Bu, ileride ürün fiyatı değişse bile, sipariş geçmişindeki eski fiyatların görüntülenmesini sağlar.
- **Stok Yönetimi**: Ürünlerin stok miktarları, sipriş işlemleri sırasında otomatik olarak güncellenir.

